package wordcounts;

class WordCounts3 {
	
	public void m1() {
		System.out.println("a");
		System.out.println("a");
	}

	public void m2() {

		int a = 10;

		int b =  20;

		if (((a>0)) && (b < 10)) {
			// ....
		}

		static class X {
			public void xxx() {
				int y = 10;
				int z = 20;
			}
		}

		String superLongVariableName = "John";
	}

	static class Y {
		public void yyy() {
			int dog = 1;
		}
	}
}