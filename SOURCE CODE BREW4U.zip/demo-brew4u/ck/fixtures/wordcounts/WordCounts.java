package wordcounts;

class WordCounts {
	
	public void m1() {
		System.out.println("a");
		System.out.println("a");
	}

	public void m2() {

		int a = 10;

		int b =  20;

		if (((a>0)) && (b < 10)) {
			// ....
		}

		String superLongVariableName = "John";
	}
}