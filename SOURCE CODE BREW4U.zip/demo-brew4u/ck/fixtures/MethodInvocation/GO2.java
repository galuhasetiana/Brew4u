package MethodInvocation;
public class GO2 {

	public void magic() {
		
	}

	public static int boring(){
		return -1;
	}
}
