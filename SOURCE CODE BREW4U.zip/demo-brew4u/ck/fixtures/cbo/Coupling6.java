package cbo;

public class Coupling6 {
	private Box<Integer> integerBox = new Box<Integer>();
}

public class Coupling61 {
	private Box2<Integer> integerBox = new Box2<Integer>();
}

public class Coupling62 {
	private Box2<A> integerBox = new Box2<A>();
}

public class Coupling63 {
	private Box<A> integerBox = new Box<A>();
}

public class Coupling64 {
	private Box<XX> integerBox = new Box<XX>();
}

public class Coupling65 {
	private Box<A> integerBox = new Box<A>();
}