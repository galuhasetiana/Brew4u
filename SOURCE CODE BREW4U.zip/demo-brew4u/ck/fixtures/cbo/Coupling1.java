package cbo;

public class Coupling1 {

	private B b;
	
	public D m1() {
		A a = new A();
		C[] x = new C[10];
		
		CouplingHelper h = new CouplingHelper();
		C2 c2 = h.m1();
		
		return d;
	}
}
