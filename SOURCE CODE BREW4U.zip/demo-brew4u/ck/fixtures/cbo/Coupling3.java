package cbo;

public class Coupling3 {

	
	public void m1() {
		// with no resolution
		Bla y;
		
	}
}
