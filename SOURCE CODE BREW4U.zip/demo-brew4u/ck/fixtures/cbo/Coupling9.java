package cbo;

class Coupling9 {
    public A[] RR() {
        B[] b = new C[10];
        return b;
    }
}