package cbo;

public class Coupling7 {
    private Box<Integer> integerBox = new Box<Integer>();
}

public class Coupling71 {
    private Box2<Integer> integerBox = new Box2<Integer>();
}

public class Coupling72 {
    private Box2<A> integerBox = new Box2<A>();
}

public class Coupling73 {
    private Box<A> integerBox = new Box<A>();
}

public class Coupling74 {
    private Box<XX> integerBox = new Box<XX>();
}

public class Coupling75 {
    private Box<A> integerBox = new Box<A>();
}
