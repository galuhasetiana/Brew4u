package lcom;

public class SimpleGetterAndSetter {

	private int f1;
	
	public int f1() {
		return f1;
	}
	
	public void setF1(f1 f1) {
		this.f1 = f1;
	}
}
