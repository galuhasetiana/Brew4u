package fields;

public class Fields {

    private int a;
    private String b;
    public double c;
    private static String d;
    public static int e;

    int f;
    static int k;

    private synchronized int j;

    protected int pr;

    public final int K = 10;

}