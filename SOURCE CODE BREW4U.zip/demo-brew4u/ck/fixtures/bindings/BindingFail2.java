package bind;

public class BindingFail2 extends SomeClass implements A1, B2, Int1 {

	public void a() {

	}

	public void x() {

	}

}