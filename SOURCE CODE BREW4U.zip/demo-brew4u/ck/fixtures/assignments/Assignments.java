package assignments;

class Assignments {
	
	public void m1() {
		int a = 10;
		int b = 20;

		b = b + 10;
		a = a + 10;

		int c;
		c = 60;
	}

	public void m2() {
		int a = 20;
		int b = a;

		int c; 
		c = a + b;
	}

	public void m3() {

	}
}