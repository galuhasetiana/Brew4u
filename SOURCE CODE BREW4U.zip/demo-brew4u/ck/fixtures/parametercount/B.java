package pcount;

class B {

	void m1() {}
}