package com.impal.demo_brew4u.config;

import java.io.IOException;
import java.util.Collection;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import com.impal.demo_brew4u.models.Admin;
import com.impal.demo_brew4u.repositories.AdminRepository;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Configuration
public class CustomAuthenticationSuccessHandler implements AuthenticationSuccessHandler {

    @Autowired
    private AdminRepository adminRepository;

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, 
                                        HttpServletResponse response, 
                                        Authentication authentication) throws IOException, ServletException {

        // Ambil Session saat ini (atau buat baru jika belum ada)
        HttpSession session = request.getSession();

        // detail user yang barusan login dari Spring Security
        User userDetails = (User) authentication.getPrincipal();
        String emailUser = userDetails.getUsername(); 

        // Cek Role User (Admin atau Pelanggan)
        Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();

        for (GrantedAuthority authority : authorities) {
            String role = authority.getAuthority();

            if (role.equals("ROLE_ADMIN")) {
                Optional<Admin> adminOptional = adminRepository.findByEmail(emailUser);
                
                if (adminOptional.isPresent()) {
                    Admin admin = adminOptional.get(); 
                    session.setAttribute("adminLog", admin);
                    
                    System.out.println("LOGIN SUKSES: Admin " + admin.getNamaAdmin() + " masuk ke session.");
                } else {
                    System.out.println("LOGIN WARNING: Admin login tapi datanya tidak ditemukan di tabel admin.");
                }

                response.sendRedirect("/admin/dashboard");
                return;
            } 
            
            else if (role.equals("ROLE_PELANGGAN")) {
                response.sendRedirect("/menu");
                return;
            }
        }

        response.sendRedirect("/menu");
    }
}