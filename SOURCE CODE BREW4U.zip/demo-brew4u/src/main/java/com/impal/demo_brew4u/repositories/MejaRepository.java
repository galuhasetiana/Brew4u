package com.impal.demo_brew4u.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.impal.demo_brew4u.models.Meja;

@Repository
public interface MejaRepository extends JpaRepository<Meja, Long> {

    @Query("SELECT m FROM Meja m WHERE m.kode_cabang = ?1")
    List<Meja> findByKode_cabang(Long kodeCabang);
}