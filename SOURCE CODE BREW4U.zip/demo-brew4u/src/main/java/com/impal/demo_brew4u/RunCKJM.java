package com.impal.demo_brew4u;

import gr.spinellis.ckjm.CkjmBean;
import gr.spinellis.ckjm.PrintPlainResults;

public class RunCKJM {

    public static void main(String[] args) throws Exception {

        // Folder hasil kompilasi
        String[] target = { "target/classes" };

        // Output ke console
        PrintPlainResults output = new PrintPlainResults(System.out);

        // Jalankan CKJM
        CkjmBean ckjm = new CkjmBean();
        ckjm.setOutputHandler(output);
        ckjm.run(target);
    }
}
