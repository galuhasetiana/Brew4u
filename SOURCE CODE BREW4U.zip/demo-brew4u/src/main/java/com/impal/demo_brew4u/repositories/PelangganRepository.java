package com.impal.demo_brew4u.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.impal.demo_brew4u.models.Pelanggan;

@Repository 
public interface PelangganRepository extends JpaRepository<Pelanggan, Long> {
    Pelanggan findByEmail(String email);
}