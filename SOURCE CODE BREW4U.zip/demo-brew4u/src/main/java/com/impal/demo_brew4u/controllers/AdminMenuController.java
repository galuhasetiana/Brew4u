package com.impal.demo_brew4u.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.impal.demo_brew4u.models.Admin;
import com.impal.demo_brew4u.models.Menu;
import com.impal.demo_brew4u.models.Rekomendasi;
import com.impal.demo_brew4u.repositories.MenuRepository;
import com.impal.demo_brew4u.repositories.RekomendasiRepository;

import jakarta.servlet.http.HttpSession;
import jakarta.transaction.Transactional;

@Controller
@RequestMapping("/admin")
public class AdminMenuController {

    @Autowired
    private MenuRepository menuRepository;

    @Autowired
    private RekomendasiRepository rekomendasiRepository;

    @GetMapping("/menu")
    public String viewMenuPage(Model model, HttpSession session) {
        Admin admin = (Admin) session.getAttribute("adminLog");
        if (admin == null) {
            return "redirect:/login";
        }
        List<Menu> menus = menuRepository.findByKode_cabang(admin.getKodeCabang());

        for (Menu m : menus) {
            if (rekomendasiRepository.existsByKode_menu(m.getKode_menu())) {
                m.setIsRecommended(true);
            } else {
                m.setIsRecommended(false);
            }
        }

        model.addAttribute("listMenu", menus);
        return "admin/menu";
    }

  
    @GetMapping("/api/menu/{id}")
    @ResponseBody
    public Menu getMenuDetail(@PathVariable long id) {
        // Ambil data menu
        Menu menu = menuRepository.findById(id).orElse(null);
        
        if (menu != null) {
            boolean isRekom = rekomendasiRepository.existsByKode_menu(menu.getKode_menu());
            menu.setIsRecommended(isRekom);
        }
        
        return menu;
    }

    @PostMapping("/menu/save")
    @Transactional
    public String saveMenu(@ModelAttribute Menu menu, 
                           @RequestParam(value = "isRecommended", required = false) boolean isRecommended,
                           HttpSession session) {
        
        Admin admin = (Admin) session.getAttribute("adminLog");
        if (admin == null) return "redirect:/login";

        menu.setKode_cabang(admin.getKodeCabang());

        Menu savedMenu = menuRepository.save(menu);

        Long kodeMenu = savedMenu.getKode_menu();

        if (isRecommended) {
            if (!rekomendasiRepository.existsByKode_menu(kodeMenu)) {
                Rekomendasi rek = new Rekomendasi(kodeMenu);
                rekomendasiRepository.save(rek);
            }
        } else {

            rekomendasiRepository.findByKode_menu(kodeMenu)
                     .ifPresent(rekomendasiRepository::delete);
        }
        
        return "redirect:/admin/menu";
    }

    @GetMapping("/menu/delete/{id}")
    @Transactional 
    public String deleteMenu(@PathVariable long id, HttpSession session) {
        Admin admin = (Admin) session.getAttribute("adminLog");
        if (admin == null) return "redirect:/login";

       
        Menu menu = menuRepository.findById(id).orElse(null);
        
        if (menu != null && menu.getKode_cabang().equals(admin.getKodeCabang())) {
            
            rekomendasiRepository.findByKode_menu(menu.getKode_menu())
                     .ifPresent(rekomendasiRepository::delete);

            menuRepository.deleteById(id);
            
            System.out.println("Sukses menghapus menu & rekomendasi: " + menu.getNama_menu());
        } else {
             System.out.println("Gagal Hapus: Menu tidak ditemukan atau beda cabang.");
        }

        return "redirect:/admin/menu";
    }
}