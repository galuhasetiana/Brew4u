package com.impal.demo_brew4u.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User; 
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.impal.demo_brew4u.models.Admin;
import com.impal.demo_brew4u.models.Pelanggan;
import com.impal.demo_brew4u.repositories.AdminRepository;
import com.impal.demo_brew4u.repositories.PelangganRepository;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private PelangganRepository pelangganRepository;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        
        
        Optional<Admin> adminOpt = adminRepository.findByEmail(email);
        
        if (adminOpt.isPresent()) {
            Admin admin = adminOpt.get();
            
            // KONVERSI: Admin -> UserDetails
            return User.builder()
                    .username(admin.getEmail())    
                    .password(admin.getPassword()) 
                    .roles("ADMIN")                
                    .build();
        }

       
        Pelanggan pelanggan = pelangganRepository.findByEmail(email);
        
        if (pelanggan != null) {
            // KONVERSI: Pelanggan -> UserDetails
            return User.builder()
                    .username(pelanggan.getEmail())
                    .password(pelanggan.getPassword())
                    .roles("PELANGGAN")            // Otomatis jadi ROLE_PELANGGAN
                    .build();
        }

       
        throw new UsernameNotFoundException("Email tidak ditemukan: " + email);
    }
}