document.addEventListener('DOMContentLoaded', () => {
    const tableSelector = document.getElementById('tableSelector');
    if (tableSelector) {
        // Update tampilan saat awal load
        updateTableDisplay(tableSelector.value);

        // Update tampilan saat user mengubah pilihan
        tableSelector.addEventListener('change', function() {
            updateTableDisplay(this.value);
        });
    }

    const checkoutForm = document.querySelector('form');
    if (checkoutForm) {
        checkoutForm.addEventListener('submit', function(event) {
            const selectedMeja = document.getElementById('tableSelector').value;


            if (!selectedMeja) {
                event.preventDefault(); // Batalkan pengiriman form
                alert('Mohon pilih Nomor Meja terlebih dahulu untuk melanjutkan!');
                return;
            }


            const btnPay = document.querySelector('.btn-pay');
            if (btnPay) {
                btnPay.innerText = 'Memproses...';
                btnPay.style.opacity = '0.7';
                btnPay.style.cursor = 'not-allowed';

            }
        });
    }
});

function updateTableDisplay(selectedValue) {
    const displaySpan = document.getElementById('selectedTableName');
    const selector = document.getElementById('tableSelector');

    if (displaySpan && selector) {
        if (selectedValue && selector.selectedIndex !== -1) {
            const selectedText = selector.options[selector.selectedIndex].text;
            displaySpan.innerText = selectedText.replace('Meja ', '');
        } else {
            displaySpan.innerText = "No. Meja";
        }
    }
}