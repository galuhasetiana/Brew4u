document.getElementById("registerForm").addEventListener("submit", async function(event) {
    event.preventDefault();

    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value.trim();
    const confirm = document.getElementById("confirmPassword").value.trim();
    const errorBox = document.getElementById("errorMessage");

    errorBox.innerText = "";

    // Validasi dasar
    if (name === "" || email === "" || password === "" || confirm === "") {
        errorBox.innerText = "Semua field wajib diisi!";
        return;
    }

    if (password !== confirm) {
        errorBox.innerText = "Password dan konfirmasi tidak cocok!";
        return;
    }

    try {
        const response = await fetch("http://localhost:8080/register", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                name: name,
                email: email,
                password: password
            })
        });

        if (response.ok) {
            alert("Registrasi berhasil!");
            window.location.href = "login.html";
        } else {
            errorBox.innerText = "Registrasi gagal! Email mungkin sudah digunakan.";
        }
    } catch (error) {
        errorBox.innerText = "Terjadi kesalahan server!";
        console.log(error);
    }
});