let cartItems = [];

document.addEventListener('DOMContentLoaded', () => {
    const items = document.querySelectorAll('.cart-item');
    items.forEach(item => {
        const id = parseInt(item.getAttribute('data-id'));
        const price = parseInt(item.getAttribute('data-price'));
        const name = item.querySelector('h2').textContent;
        const quantity = parseInt(item.querySelector(`#qty-${id}`).textContent);

        cartItems.push({ id, name, price, quantity });
    });
    calculateTotal();
});

function formatRupiah(number) {
    return new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0
    }).format(number);
}

function updateQuantity(itemId, delta) {
    const item = cartItems.find(i => i.id === itemId);
    if (!item) return;

    if (item.quantity + delta < 1) {
        const currentQty = item.quantity;
        showCustomMessage(`Yakin ingin menghapus ${item.name} dari keranjang?`, 'confirm', () => removeItem(itemId));
        document.getElementById(`qty-${itemId}`).textContent = currentQty;
        return;
    }

    fetch('/cart/update', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `kodeMenu=${itemId}&delta=${delta}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                item.quantity += delta;
                document.getElementById(`qty-${itemId}`).textContent = item.quantity;
                calculateTotal();
            } else {
                showCustomMessage('Gagal mengupdate keranjang!', 'error');
            }
        })
        .catch(error => {
            console.error('Error updating cart:', error);
            showCustomMessage('Terjadi kesalahan koneksi.', 'error');
        });
}

function removeItem(itemId) {
    const item = cartItems.find(i => i.id === itemId);
    if (!item) return;

    fetch('/cart/update', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `kodeMenu=${itemId}&delta=${-item.quantity}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                cartItems = cartItems.filter(i => i.id !== itemId);
                const itemElement = document.querySelector(`.cart-item[data-id="${itemId}"]`);
                if (itemElement) itemElement.remove();

                calculateTotal();
                showCustomMessage('Item berhasil dihapus!', 'success');
            }
        })
        .catch(error => {
            console.error('Error removing item:', error);
            showCustomMessage('Gagal menghapus item.', 'error');
        });
}

function calculateTotal() {
    let subtotal = 0;
    let totalItems = 0;

    cartItems.forEach(item => {
        subtotal += item.price * item.quantity;
        totalItems += item.quantity;

        const priceDisplay = document.getElementById(`price-display-${item.id}`);
        if (priceDisplay) {
            priceDisplay.textContent = formatRupiah(item.price * item.quantity);
        }
    });

    const discount = 0;


    const subTotalElement = document.getElementById('subTotal');
    const grandTotalElement = document.getElementById('grandTotal');
    const totalItemsElement = document.getElementById('totalItems');
    const emptyMessage = document.getElementById('emptyCartMessage');
    const checkoutContainer = document.getElementById('checkoutContainer');
    const discountElement = document.getElementById('discount');

    if (totalItemsElement) totalItemsElement.textContent = totalItems;
    if (subTotalElement) subTotalElement.textContent = formatRupiah(subtotal);
    if (grandTotalElement) grandTotalElement.textContent = formatRupiah(subtotal - discount);
    if (discountElement) discountElement.textContent = formatRupiah(discount);

    if (cartItems.length === 0) {
        if (emptyMessage) emptyMessage.style.display = 'block';
        if (checkoutContainer) checkoutContainer.style.display = 'none';
    } else {
        if (emptyMessage) emptyMessage.style.display = 'none';
        if (checkoutContainer) checkoutContainer.style.display = 'block';
    }
}

function showCustomMessage(text, type, onConfirm = null) {
    const messageBox = document.getElementById('messageBox');
    messageBox.innerHTML = '';
    messageBox.classList.remove('success', 'error', 'confirm', 'visible');

    const messageText = document.createElement('span');
    messageText.textContent = text;
    messageBox.appendChild(messageText);

    if (type === 'confirm') {
        const buttonContainer = document.createElement('div');
        buttonContainer.style.display = 'flex';
        buttonContainer.style.gap = '10px';
        buttonContainer.style.marginTop = '10px';

        const cancelButton = document.createElement('button');
        cancelButton.textContent = 'Batal';
        cancelButton.style.padding = '8px 16px';
        cancelButton.style.border = 'none';
        cancelButton.style.borderRadius = '4px';
        cancelButton.style.cursor = 'pointer';
        cancelButton.style.backgroundColor = '#6c757d';
        cancelButton.style.color = 'white';
        cancelButton.onclick = () => {
            messageBox.classList.remove('visible');
        };
        buttonContainer.appendChild(cancelButton);

        const confirmButton = document.createElement('button');
        confirmButton.textContent = 'Ya, Hapus';
        confirmButton.style.padding = '8px 16px';
        confirmButton.style.border = 'none';
        confirmButton.style.borderRadius = '4px';
        confirmButton.style.cursor = 'pointer';
        confirmButton.style.backgroundColor = '#dc3545';
        confirmButton.style.color = 'white';
        confirmButton.onclick = () => {
            onConfirm();
            messageBox.classList.remove('visible');
        };
        buttonContainer.appendChild(confirmButton);

        messageBox.appendChild(buttonContainer);
        messageBox.classList.add('confirm');
    } else {
        if (type === 'success') {
            messageBox.style.backgroundColor = '#065f46';
            messageBox.style.color = 'white';
        } else if (type === 'error') {
            messageBox.style.backgroundColor = '#dc3545';
            messageBox.style.color = 'white';
        }

        setTimeout(() => {
            messageBox.classList.remove('visible');
        }, 3000);
    }

    messageBox.classList.add('visible');
}