const modal = document.getElementById("stokModal");

// FUNGSI BUKA MODAL UPDATE
function openUpdateModal(id) {
    // Panggil API untuk ambil data stok menu saat ini
    fetch('/admin/api/stok-menu/' + id)
        .then(res => res.json())
        .then(data => {
            document.getElementById("mId").value = data.kode_menu;
            document.getElementById("mNamaDisplay").value = data.nama_menu;
            document.getElementById("mStokLama").value = data.stok;

            // Set input stok baru default ke stok lama
            const inputBaru = document.getElementById("mStokBaru");
            inputBaru.value = data.stok;

            modal.style.display = "flex";
            inputBaru.focus();
            inputBaru.select();
        })
        .catch(err => console.error(err));
}

function closeModal() {
    modal.style.display = "none";
}

// Tutup modal jika klik di luar area putih
window.onclick = function(e) {
    if (e.target == modal) closeModal();
}