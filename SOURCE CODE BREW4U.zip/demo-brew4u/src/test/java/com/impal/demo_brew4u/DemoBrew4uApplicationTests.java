package com.impal.demo_brew4u;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoBrew4uApplicationTests {

	@Test
	void contextLoads() {
	}

}
