// package com.impal.demo_brew4u.controllers;

// import org.junit.jupiter.api.Test;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.test.web.servlet.MockMvc;
// import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
// import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
// import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrlPattern;
// import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
// @SpringBootTest
// @AutoConfigureMockMvc
// public class AdminMenuControllerTest {

//     @Autowired
//     private MockMvc mockMvc;
//     @Test
//     public void testViewMenuPage_RedirectJikaBelumLogin() throws Exception {
//         mockMvc.perform(get("/admin/menu"))
//             .andExpect(status().is3xxRedirection())
//             // Gunakan redirectedUrlPattern untuk menangani prefix http://localhost
//             .andExpect(redirectedUrlPattern("**/login"));
//     }

//     @Test
//     public void testProcessPayment_CartEmpty_Redirect() throws Exception {
//         mockMvc.perform(post("/pembayaran/proses")
//             .param("kodeMeja", "T01"))
//             .andExpect(status().is3xxRedirection())
//             // Jika aplikasi memaksa login, sesuaikan ekspektasi ke login
//             .andExpect(redirectedUrlPattern("**/login"));
//     }
// }