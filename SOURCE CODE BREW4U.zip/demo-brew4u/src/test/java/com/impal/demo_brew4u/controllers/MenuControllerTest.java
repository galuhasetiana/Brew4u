// package com.impal.demo_brew4u.controllers;

// import org.junit.jupiter.api.Test;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.test.web.servlet.MockMvc;
// import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
// import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

// /**
//  * Controller Test TANPA Service
//  * Cocok jika logic langsung ada di MenuController
//  */
// @SpringBootTest
// @AutoConfigureMockMvc
// class MenuControllerTest {

//     @Autowired
//     private MockMvc mockMvc;

//     @Test
//     void testGetAllMenu_success() throws Exception {
//         mockMvc.perform(get("/menu"))
//                .andExpect(status().isOk());
//     }
// }

