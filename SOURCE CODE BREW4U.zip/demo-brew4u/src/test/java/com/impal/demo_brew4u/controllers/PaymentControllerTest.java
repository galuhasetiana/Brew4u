package com.impal.demo_brew4u.controllers;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import com.impal.demo_brew4u.models.Menu;
import com.impal.demo_brew4u.models.Pelanggan;
import com.impal.demo_brew4u.models.Pesanan;
import com.impal.demo_brew4u.repositories.DetailPesananRepository;
import com.impal.demo_brew4u.repositories.MejaRepository;
import com.impal.demo_brew4u.repositories.MenuRepository;
import com.impal.demo_brew4u.repositories.PelangganRepository;
import com.impal.demo_brew4u.repositories.PesananRepository;
import com.midtrans.httpclient.SnapApi;

import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(PaymentController.class)
class PaymentControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean private MenuRepository menuRepository;
    @MockBean private MejaRepository mejaRepository;
    @MockBean private PelangganRepository pelangganRepository;
    @MockBean private PesananRepository pesananRepository;
    @MockBean private DetailPesananRepository detailPesananRepository;

    // TEST 1: GET /pembayaran → sukses tampil halaman
    @Test
    @WithMockUser(username = "user@email.com")
    void showPaymentPage_success() throws Exception {

        Menu menu = new Menu();
        menu.setHarga(BigDecimal.valueOf(20000));

        Map<Long, Integer> cart = new HashMap<>();
        cart.put(1L, 2);

        when(menuRepository.findById(1L)).thenReturn(Optional.of(menu));
        when(pelangganRepository.findByEmail("user@email.com"))
                .thenReturn(new Pelanggan());

        mockMvc.perform(get("/pembayaran")
                .sessionAttr("cart", cart))
                .andExpect(status().isOk())
                .andExpect(view().name("detailpembayaran"))
                .andExpect(model().attributeExists("cartItems"))
                .andExpect(model().attributeExists("grandTotal"))
                .andExpect(model().attributeExists("user"));
    }


    // TEST 2: POST /pembayaran/proses → sukses
    @Test
    @WithMockUser(username = "user@email.com")
    void processPayment_success() throws Exception {

        Menu menu = new Menu();
        menu.setHarga(BigDecimal.valueOf(10000));
        menu.setStok(10);

        Pelanggan pelanggan = new Pelanggan();
        pelanggan.setNama_pelanggan("User Test");
        pelanggan.setEmail("user@email.com");

        Pesanan savedPesanan = new Pesanan();
        savedPesanan.setKode_pesanan(1L);

        Map<Long, Integer> cart = new HashMap<>();
        cart.put(1L, 2);

        when(menuRepository.findById(1L)).thenReturn(Optional.of(menu));
        when(pelangganRepository.findByEmail("user@email.com"))
                .thenReturn(pelanggan);
        when(pesananRepository.save(any(Pesanan.class)))
                .thenReturn(savedPesanan);

        try (MockedStatic<SnapApi> snapApiMock = org.mockito.Mockito.mockStatic(SnapApi.class)) {
            snapApiMock.when(() -> SnapApi.createTransactionToken(any()))
                    .thenReturn("dummy-snap-token");

            mockMvc.perform(post("/pembayaran/proses")
                    .with(csrf()) 
                    .param("kodeMeja", "1")
                    .sessionAttr("cart", cart)
                    .sessionAttr("currentCabangId", 1L))
                    .andExpect(status().isOk())
                    .andExpect(view().name("payment"))
                    .andExpect(model().attributeExists("snapToken"))
                    .andExpect(model().attributeExists("pesanan"));
        }
    }

    // TEST 3: POST /pembayaran/proses → cart kosong
    @Test
    @WithMockUser
    void processPayment_cartEmpty_redirectMenu() throws Exception {

        mockMvc.perform(post("/pembayaran/proses")
                .with(csrf()) 
                .param("kodeMeja", "1"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/menu"));
    }

    // TEST 4: GET /pembayaran/sukses → update status
    @Test
    @WithMockUser
    void paymentSuccess_updateStatus() throws Exception {

        Pesanan pesanan = new Pesanan();
        pesanan.setStatusPembayaran("pending");

        when(pesananRepository.findById(1L))
                .thenReturn(Optional.of(pesanan));

        mockMvc.perform(get("/pembayaran/sukses")
                .param("orderId", "1"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/konfirmasi_sukses"));
    }
}
